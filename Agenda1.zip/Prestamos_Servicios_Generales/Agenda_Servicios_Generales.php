<?php
require_once 'utils.php';
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="SERVICIOS GENERALES">
    <meta name="author" content="Aaron Yael.pt">
	<link rel="shortcut icon" href="assets/img/favicon.png" type="image/x-icon" >

    <title>SERVICIOS GENERALES</title>

    <!-- Bootstrap Core CSS -->
    <link href="assets/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link href="assets/css/styles.css" rel="stylesheet">	
	<!-- DateTimePicker CSS -->
	<link href="assets/css/bootstrap-datetimepicker.min.css" rel="stylesheet" media="screen">	
	<!-- DataTables CSS -->
    <link href="assets/css/dataTables.bootstrap.css" rel="stylesheet">	
	<!-- FullCalendar CSS -->
	<link href="assets/css/fullcalendar.css" rel="stylesheet" />
	<link href="assets/css/fullcalendar.print.css" rel="stylesheet" media="print" />	
	<!-- jQuery -->
    <script src="assets/js/jquery.js"></script>	
	<!-- SweetAlert CSS -->
	<script src="assets/js/sweetalert.min.js"></script> 
	<link rel="stylesheet" type="text/css" href="assets/css/sweetalert.css">
    <!-- Custom Fonts -->
    <link href="assets/font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css?family=Lato:300,400,700,300italic,400italic,700italic" rel="stylesheet" type="text/css">
	<!-- ColorPicker CSS -->
	<link href="assets/css/bootstrap-colorpicker.css" rel="stylesheet">
	
	<script src="assets/js/isotope.pkgd.min.js"></script> 
	

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

	<body>
		<!-- Navigation -->
		<nav class="navbar navbar-expand-lg fixed-top navbar-dark bg-dark ">
		  <div class="container topnav">
			<a class="navbar-brand" href="#home"><h1><i class="fa fa-calendar-days" aria-hidden="true"></i> Servicios Generales</h1></a>
			<button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup" aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
			  <span class="navbar-toggler-icon"></span>
			</button>
			<div class="collapse navbar-collapse justify-content-end" id="navbarNavAltMarkup">
			  <div class="navbar-nav">
				<a class="nav-link active" aria-current="page" href="#home">Inicio</a>
				<a class="nav-link" href="#eventcalendar">Agenda</a>
				<!--<a class="nav-link" href="#ticket_events">Tickets</a>-->
			  </div>
			</div>
		  </div>
		</nav>

		<!-- Header -->
	   <div id="home"></div>
		<div class="intro-header">
			<div class="container">

				<div class="row">
					<div class="col-lg-12">
						<div class="intro-message">
							<h1><i class="fa fa-calendar-days" aria-hidden="true"></i> Servicios Generales</h1>
							<h3>Agenda de prestamos</h3>
							<hr class="intro-divider">                       
						</div>
					</div>
				</div>

			</div>
			<!-- /.container -->

		</div>
		<!-- /.intro-header -->

		<!-- Page Content -->
		<div id="eventcalendar"></div>
		<div class="content-section-a">
			
			<!--BEGIN PLUGIN -->
			<div class="container">
			
			<h1><i class="fa fa-calendar-days" aria-hidden="true"></i> Agenda</h1>
			
				<div class="row">
				   <div class="col-lg-12">
				<div class="panel panel-default dash">
					
					<div class="panel panel-default">
						<div class="panel-heading">
							<!-- Button trigger New Event modal -->
							<button type="button" class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#event">
							 <i class="fa fa-calendar-days" aria-hidden="true"></i> New Event
							</button>
							<!-- New Event Creation Modal -->
							<div class="modal fade" id="event" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa fa-calendar' aria-hidden='true'></i> New Event</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">
											 <!-- New Event Creation Form -->
											<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" name="novoevento">
												<fieldset>
													<!-- CSRF PROTECTION -->
													<input type="hidden" name="_csrf" value="de2c2fea4464a643855cc8be9b0cf117" />													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="title">Title</label>
														<div class="col-md-4">
															<select name='title' class="form-control form-select input-md">
																
																<option value='No type Selected' required>Select Type</option>
																	
																	<option value='Watch Party'>Watch Party</option>
																	
																	
																	
																	<option value='aaa'>aaa</option>
																	
																	
																	
																	<option value='TEST'>TEST</option>
																	
																	
																	
																	<option value='ak'>ak</option>
																	
																	
																	
																	<option value='Test'>Test</option>
																	
																	
																	
																	<option value='Location'>Location</option>
																	
																	
																	
																	<option value='yyyyyyyyyy'>yyyyyyyyyy</option>
																	
																	
																	
																	<option value='Conference'>Conference</option>
																	
																																</select>
														</div>
													</div>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="color">Color</label>
														<div class="col-md-4">
															<div id="cp1" class="input-group colorpicker-component">
																<input id="cp1" type="text" class="form-control form-control-color" name="color" value="#5367ce" required/>
																<span class="input-group-addon"><i></i></span>
															</div>
														</div>
													</div>
													<div class="form-group col-md-6">
														<label class="col-md-3 control-label" for="start">Start Date</label>
														<div class="input-group date form_date col-md-6" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="start" data-link-format="yyyy-mm-dd hh:ii">
															<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span><input class="form-control" size="16" type="text" value="" readonly>
														</div>
														<input id="start" name="start" type="hidden" value="" required>

													</div>

													<div class="form-group col-md-6">
														<label class="col-md-3 control-label" for="end">End Date</label>
														<div class="input-group date form_date col-md-6" data-date="" data-date-format="yyyy-mm-dd hh:ii" data-link-field="end" data-link-format="yyyy-mm-dd hh:ii">
															<span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span><input class="form-control" size="16" type="text" value="" readonly>
														</div>
														<input id="end" name="end" type="hidden" value="" required>

													</div>
													
													<!-- Image input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="image">Upload Image</label>
														<div class="col-md-12">
															<input type="file" name="image" id="image">
														</div>
													</div>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="url">Link</label>
														<div class="col-md-12">
															<input id="url" name="url" type="text" class="form-control input-md" required>

														</div>
													</div>

													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="description">Description</label>
														<div class="col-md-12">
															<textarea class="form-control" rows="5" name="description" id="description"></textarea>
														</div>
													</div>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="location">Location</label>
														<div class="col-md-12">
															<textarea class="form-control" rows="1" name="location" id="location"></textarea>
														</div>
													</div>


													<!-- Button -->
													<div class="form-group">
														<label class="col-md-12 control-label" for="singlebutton"></label>
														<div class="col-md-4">
															<input type="submit" name="novoevento" class="btn btn-success" value="New Event" />
														</div>
													</div>

												</fieldset>
											</form>  
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
										</div>
									</div>
								</div>
							</div>							
														
							<!-- New Event Creation Modal for the selectable date -->
							<div class="modal fade" id="event1" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa fa-calendar' aria-hidden='true'></i> New Event</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">
											 <!-- New Event Creation Form -->
											<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" name="novoevento">
												<fieldset>
													<!-- CSRF PROTECTION -->
													<input type="hidden" name="_csrf" value="de2c2fea4464a643855cc8be9b0cf117" />													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="title">Title</label>
														<div class="col-md-4">
															<select name='title' class="form-control form-select input-md">
																
																<option value='No type Selected' required>Select Type</option>
																	
																	<option value='Watch Party'>Watch Party</option>
																	
																	
																	
																	<option value='aaa'>aaa</option>
																	
																	
																	
																	<option value='TEST'>TEST</option>
																	
																	
																	
																	<option value='ak'>ak</option>
																	
																	
																	
																	<option value='Test'>Test</option>
																	
																	
																	
																	<option value='Location'>Location</option>
																	
																	
																	
																	<option value='yyyyyyyyyy'>yyyyyyyyyy</option>
																	
																	
																	
																	<option value='Conference'>Conference</option>
																	
																																</select>
														</div>
													</div>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="color">Color</label>
														<div class="col-md-4">
															<div id="cp2" class="input-group colorpicker-component">
																<input id="cp2" type="text" class="form-control" name="color" value="#5367ce" required/>
																<span class="input-group-addon"><i></i></span>
															</div>
														</div>
													</div>

													
													<input id="start" class="form-control" name="start" type="hidden" value="">
													<input id="end" class="form-control" name="end" type="hidden" value="">


													<!-- Image input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="image">Upload Image</label>
														<div class="col-md-12">
															<input type="file" name="image" id="image">
														</div>
													</div>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="url">Link</label>
														<div class="col-md-12">
															<input id="url" name="url" type="text" class="form-control input-md" required>

														</div>
													</div>

													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="description">Description</label>
														<div class="col-md-12">
															<textarea class="form-control" rows="5" name="description" id="description"></textarea>
														</div>
													</div>
													
													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="location">Location</label>
														<div class="col-md-12">
															<textarea class="form-control" rows="1" name="location" id="location"></textarea>
														</div>
													</div>


													<!-- Button -->
													<div class="form-group">
														<label class="col-md-12 control-label" for="singlebutton"></label>
														<div class="col-md-4">
															<input type="submit" name="novoevento" class="btn btn-success" value="New Event" />
														</div>
													</div>

												</fieldset>
											</form>  
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
										</div>
									</div>
								</div>
							</div>														
							
							<!-- Button trigger New Type modal -->
							<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#type">
								<i class="fa fa-globe" aria-hidden="true"></i> New Type
							</button>
							 <!-- New Type Creation Form -->
							<div class="modal fade" id="type" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa fa-calendar' aria-hidden='true'></i> New Type</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">                               
											<!-- New Event Creation Form -->
											<form action="" method="post" enctype="multipart/form-data" class="form-horizontal" name="novotipo">
												<fieldset>
													<!-- CSRF PROTECTION -->
													<input type="hidden" name="_csrf" value="de2c2fea4464a643855cc8be9b0cf117" />													<!-- Text input-->
													<div class="form-group">
														<label class="col-md-3 control-label" for="title">Title</label>
														<div class="col-md-12">
															<input id="title" name="title" type="text" class="form-control input-md" required>

														</div>
													</div>
													
													<!-- Button -->
													<div class="form-group">
														<label class="col-md-12 control-label" for="singlebutton"></label>
														<div class="col-md-4">
															<input type="submit" name="novotipo" class="btn btn-success" value="New Type" />
														</div>
													</div>

												</fieldset>
											</form>
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
										</div>
									</div>
								</div>
							</div>
							
							<!-- Button trigger Delete Event modal -->
							<button type="button" class="btn btn-info" data-bs-toggle="modal" data-bs-target="#editevent">
								<i class="fa fa-edit" aria-hidden="true"></i> Edit Events
							</button>

							<!-- Modal -->
							<div class="modal fade" id="editevent" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa fa-calendar-days' aria-hidden='true'></i> Edit Events</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">
											<!-- Modal featuring all events saved on database -->
											<table class='table table-striped table-bordered table-hover dataTables-example' id='dataTables-example'>  <thead>
                <tr>	
                  <th>TITLE</th>
				  <th>LINK</th>
				  <th>START DATE</th>
				  <th>END DATE</th>
				  <th></th>
                </tr>
              </thead><tr><td>Location</td><td>dfdr</td><td>2022-11-01 14:10:00</td><td>2022-11-24 14:10:00</td><td class='r'>
			<a href='events_edit.php?id=1399' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Location</td><td>asdsd</td><td>2022-11-13 19:10:00</td><td>2022-11-20 23:30:00</td><td class='r'>
			<a href='events_edit.php?id=1400' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Location</td><td>nada</td><td>2022-11-14 00:00:00</td><td>2022-11-15 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1401' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>aaa</td><td>www.tactic.cc</td><td>2022-11-16 10:05:00</td><td>2022-11-16 17:25:00</td><td class='r'>
			<a href='events_edit.php?id=1404' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Faktura</td><td>test</td><td>2022-11-17 00:00:00</td><td>2022-11-18 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1387' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Faktura</td><td>dxx</td><td>2022-11-17 05:50:00</td><td>2022-11-20 22:45:00</td><td class='r'>
			<a href='events_edit.php?id=1374' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Watch Party</td><td>https://c06f4633e8fbf280ff7b-531ca14677673103300e8c53210a758f.ssl.cf1.rackcdn.com/SEACRET_40933.png</td><td>2022-11-17 08:00:00</td><td>2022-11-19 22:50:00</td><td class='r'>
			<a href='events_edit.php?id=1405' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>No type Selected</td><td>sagar.com</td><td>2022-11-23 00:00:00</td><td>2022-11-24 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1394' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Test</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-24 17:20:00</td><td>2022-11-24 23:30:00</td><td class='r'>
			<a href='events_edit.php?id=1389' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Conference</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-25 00:00:00</td><td>2022-11-26 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1391' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Location</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-25 06:30:00</td><td>2022-11-25 21:40:00</td><td class='r'>
			<a href='events_edit.php?id=1393' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>nuovo tipo</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-26 18:40:00</td><td>2022-11-26 22:50:00</td><td class='r'>
			<a href='events_edit.php?id=1392' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>No type Selected</td><td>anysite.com</td><td>2022-11-27 15:05:00</td><td>2022-11-30 18:05:00</td><td class='r'>
			<a href='events_edit.php?id=1373' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Faktura</td><td>6j56j56j</td><td>2022-11-30 00:00:00</td><td>2022-12-04 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1396' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>nuovo tipo</td><td>https://www.tenwavehealthcare.com/</td><td>2022-12-31 00:00:00</td><td>2023-01-01 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1383' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr><tr><td>Conference</td><td>http://www.tenwave.in/</td><td>2023-01-01 00:00:00</td><td>2023-01-02 00:00:00</td><td class='r'>
			<a href='events_edit.php?id=1382' class='btn btn-primary btn-sm' role='button'><i class='fa fa-fw fa-edit'></i> EDIT</a></td></tr></table>
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
										</div>
									</div>
								</div>
							</div>
							
							<!-- Button trigger Delete Event modal -->
							<button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#delevent">
								<i class="fa fa-close" aria-hidden="true"></i> Delete Events
							</button>

							<!-- Modal -->
							<div class="modal fade" id="delevent" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa fa-calendar' aria-hidden='true'></i> Delete Events</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">
											<!-- Modal featuring all events saved on database -->
											<table class='table table-striped table-bordered table-hover dataTables-example' id='dataTables-example'>  <thead>
                <tr>	
                  <th>TITLE</th>
				  <th>LINK</th>
				  <th>START DATE</th>
				  <th>END DATE</th>
				  <th></th>
                </tr>
              </thead><tr><td>Location</td><td>dfdr</td><td>2022-11-01 14:10:00</td><td>2022-11-24 14:10:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1399)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Location</td><td>asdsd</td><td>2022-11-13 19:10:00</td><td>2022-11-20 23:30:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1400)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Location</td><td>nada</td><td>2022-11-14 00:00:00</td><td>2022-11-15 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1401)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>aaa</td><td>www.tactic.cc</td><td>2022-11-16 10:05:00</td><td>2022-11-16 17:25:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1404)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Faktura</td><td>test</td><td>2022-11-17 00:00:00</td><td>2022-11-18 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1387)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Faktura</td><td>dxx</td><td>2022-11-17 05:50:00</td><td>2022-11-20 22:45:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1374)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Watch Party</td><td>https://c06f4633e8fbf280ff7b-531ca14677673103300e8c53210a758f.ssl.cf1.rackcdn.com/SEACRET_40933.png</td><td>2022-11-17 08:00:00</td><td>2022-11-19 22:50:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1405)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>No type Selected</td><td>sagar.com</td><td>2022-11-23 00:00:00</td><td>2022-11-24 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1394)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Test</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-24 17:20:00</td><td>2022-11-24 23:30:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1389)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Conference</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-25 00:00:00</td><td>2022-11-26 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1391)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Location</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-25 06:30:00</td><td>2022-11-25 21:40:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1393)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>nuovo tipo</td><td>https://codecanyon.net/user/ezcode</td><td>2022-11-26 18:40:00</td><td>2022-11-26 22:50:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1392)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>No type Selected</td><td>anysite.com</td><td>2022-11-27 15:05:00</td><td>2022-11-30 18:05:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1373)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Faktura</td><td>6j56j56j</td><td>2022-11-30 00:00:00</td><td>2022-12-04 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1396)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>nuovo tipo</td><td>https://www.tenwavehealthcare.com/</td><td>2022-12-31 00:00:00</td><td>2023-01-01 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1383)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>Conference</td><td>http://www.tenwave.in/</td><td>2023-01-01 00:00:00</td><td>2023-01-02 00:00:00</td><td class='r'>
			<a href='javascript:EliminaEvento(1382)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr></table>
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
										</div>
									</div>
								</div>
							</div>

							<button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deltype">
								<i class="fa fa-close" aria-hidden="true"></i> Delete Types
							</button>

							<!-- Modal Borrar tipo-->
							<div class="modal fade" id="deltype" tabindex="-1" role="dialog" aria-labelledby="myModalLabel3">
								<div class="modal-dialog" role="document">
									<div class="modal-content">
										<div class='modal-header'>
											<h5 class='modal-title'><i class='fa fa-calendar' aria-hidden='true'></i> Delete Types</h5>
											<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
										</div>
										<div class="modal-body">
											<!-- Modal featuring all types saved on database -->
											<table class='table table-striped table-bordered table-hover dataTables-example' id='dataTables-example'>  <thead>
                <tr>
					<th>ID</th>				
					<th>TITLE</th>					
					<th></th>
                </tr>
              </thead><tr><td>390</td><td>Conference</td><td class='r'>			
			<a href='javascript:EliminaTipo(390)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>391</td><td>yyyyyyyyyy</td><td class='r'>			
			<a href='javascript:EliminaTipo(391)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>392</td><td>Location</td><td class='r'>			
			<a href='javascript:EliminaTipo(392)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>394</td><td>Test</td><td class='r'>			
			<a href='javascript:EliminaTipo(394)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>396</td><td>ak</td><td class='r'>			
			<a href='javascript:EliminaTipo(396)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>398</td><td>TEST</td><td class='r'>			
			<a href='javascript:EliminaTipo(398)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>399</td><td>aaa</td><td class='r'>			
			<a href='javascript:EliminaTipo(399)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr><tr><td>400</td><td>Watch Party</td><td class='r'>			
			<a href='javascript:EliminaTipo(400)'class='btn btn-danger btn-sm' role='button'><i class='fa fa-fw fa-trash'></i> DELETE</a></td></tr></table>
										</div>
										<div class="modal-footer">
											<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
										</div>
									</div>
								</div>
							</div>
						</div>
						<!-- /.panel-heading -->
						<div class="panel-body">
							<div class="col-lg-12">
								<div id="events"></div>
							</div>				
						</div>
					</div>
				</div>
			</div>
						<!-- Modal with events description -->
				
	
	<div id='fullCalModal' class='modal' tabindex='-1'>
	  <div class='modal-dialog'>
		<div class='modal-content'>
		  <div class='modal-header'>
			<h5 class='modal-title'><i class='fa fa-calendar' aria-hidden='true'></i> EVENT DETAILS</h5>
			<button type='button' class='btn-close' data-bs-dismiss='modal' aria-label='Close'></button>
		  </div>
		  <div class='modal-body'>
				<div class='table-responsive'>
					<div class='col-md-12'>
						<a id='eventUrl' target='_blank'><h4><i class='fa fa-calendar' aria-hidden='true'></i> <span id='modalTitle'></span></h4></a>
						<!--<p><i class='fa fa-clock-o' aria-hidden='true'></i> <span id='startTime'></span> to <span id='endTime'></span></p> //Enable for displaying time. Use this only for the create event button method --> 
					</div>
					<div class='col-md-12'>	
						<div id='imageDiv'> </div>
						<br/>
						<h4><i class='fa fa-globe'></i> DESCRIPTION:</h4>
						 <p id='modalBody'></p>
						<h4><i class='fa fa-map-marker'></i> LOCATION:</h4>
						 <p id='modalBodyLoc'></p>
					</div>
				</div>
			</div>
		  <div class='modal-footer'>
			<button type='button' class='btn btn-primary' data-bs-dismiss='modal'>Close</button>
		  </div>
		</div>
	  </div>
	</div>
				</div>

			</div>
			<!-- /.container -->

		</div>
		
		
		<!--<div id="ticket_events"></div>
		<div class="content-section-b">

			<div class="container">
				<section>
				<h1>Tickets</h1>
				<div class="row">				
					<p>
					<select class="filters-select">
					  <option value='*'>show all</option>
					  <option value=.Location>Location</option><option value=.yyyyyyyyyy>yyyyyyyyyy</option><option value=.Test>Test</option><option value=.Conference>Conference</option><option value=.aaa>aaa</option><option value=.ak>ak</option><option value=.Watch Party>Watch Party</option><option value=.TEST>TEST</option>					</select>
					</p>

					<div class="grid">
					  
			<div class='element-item transition Location' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='01 November 2022'>
					 <span>01 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> 5h</small>
					 <h3>Location</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   dfdr
						   <a href='dfdr' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Location' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='13 November 2022'>
					 <span>13 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> dssdsd</small>
					 <h3>Location</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 19:10 to 23:30</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   asdsd
						   <a href='asdsd' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Location' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='14 November 2022'>
					 <span>14 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> </small>
					 <h3>Location</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   nada
						   <a href='nada' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition aaa' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='16 November 2022'>
					 <span>16 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> oficines</small>
					 <h3>aaa</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 10:05 to 17:25</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   aaa
						   <a href='aaa' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Faktura' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='17 November 2022'>
					 <span>17 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> </small>
					 <h3>Faktura</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   test
						   <a href='test' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Faktura' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='17 November 2022'>
					 <span>17 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> </small>
					 <h3>Faktura</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 05:50 to 22:45</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   dxx
						   <a href='dxx' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Watch Party' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='17 November 2022'>
					 <span>17 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> Japan</small>
					 <h3>Watch Party</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 08:00 to 22:50</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   https://c06f4633e8fbf280ff7b-531ca14677673103300e8c53210a758f.ssl.cf1.rackcdn.com/SEACRET_40933.png
						   <a href='https://c06f4633e8fbf280ff7b-531ca14677673103300e8c53210a758f.ssl.cf1.rackcdn.com/SEACRET_40933.png' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition No type Selected' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='23 November 2022'>
					 <span>23 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> wr</small>
					 <h3>No type Selected</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   sagar.com
						   <a href='sagar.com' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Test' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='24 November 2022'>
					 <span>24 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> portugal</small>
					 <h3>Test</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 17:20 to 23:30</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   https://codecanyon.net/user/ezcode
						   <a href='https://codecanyon.net/user/ezcode' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Conference' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='25 November 2022'>
					 <span>25 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> cvbcbcb</small>
					 <h3>Conference</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   https://codecanyon.net/user/ezcode
						   <a href='https://codecanyon.net/user/ezcode' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Location' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='25 November 2022'>
					 <span>25 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> vbnvbnvbn</small>
					 <h3>Location</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 06:30 to 21:40</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   https://codecanyon.net/user/ezcode
						   <a href='https://codecanyon.net/user/ezcode' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition nuovo tipo' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='26 November 2022'>
					 <span>26 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> xcvbxbvxb</small>
					 <h3>nuovo tipo</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 18:40 to 22:50</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   https://codecanyon.net/user/ezcode
						   <a href='https://codecanyon.net/user/ezcode' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition No type Selected' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='27 November 2022'>
					 <span>27 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> anywhere</small>
					 <h3>No type Selected</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> 15:05 to 18:05</span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   anysite.com
						   <a href='anysite.com' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Faktura' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='30 November 2022'>
					 <span>30 November 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> 6j56j5</small>
					 <h3>Faktura</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   6j56j56j
						   <a href='6j56j56j' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition nuovo tipo' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='31 December 2022'>
					 <span>31 December 2022</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> safds</small>
					 <h3>nuovo tipo</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   https://www.tenwavehealthcare.com/
						   <a href='https://www.tenwavehealthcare.com/' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
			
			<div class='element-item transition Conference' data-category='transition'>
				<article class='card fl-left'>
				  <section class='dates'>
					 <time datetime='01 January 2023'>
					 <span>01 January 2023</span>
					 </time>
				  </section>
				  <section class='card-cont'>
					 <small><i class='fa fa-map-marker'></i> ert</small>
					 <h3>Conference</h3>
					 <div class='even-date'>
						<i class='fa fa-clock-o'></i>
						
					<span> All Day </span>
						
					 </div>
					 </br>
					 <div class='even-info'>
						<p>
						   http://www.tenwave.in/
						   <a href='http://www.tenwave.in/' target='_blank'>Visit</a>
						</p>
						
					 </div>
					 
				  </section>
			   </article>
			</div>
								</div>
					
				</div>
				</section>
			</div>
		</div>-->
		<!-- /.container -->
		
		

		</div>
		<!-- /.banner -->

		<!-- Footer -->
		<footer>
			<div class="container">
				<div class="row">
					<div class="col-lg-12">                   
						<!--<p class="copyright text-muted small">Copyright &copy; CUALTOS 2022. All Rights Reserved</p>-->
					</div>
				</div>
			</div>
		</footer>

		<!-- Bootstrap Core JavaScript -->
		<script src="assets/js/bootstrap.min.js"></script>
		<!-- DataTables JavaScript -->
		<script src="assets/js/jquery.dataTables.js"></script>
		<script src="assets/js/dataTables.bootstrap.js"></script>
		<!-- Listings JavaScript delete options-->
		<script src="assets/js/listings.js"></script>
		<!-- Metis Menu Plugin JavaScript -->
		<script src="assets/js/metisMenu.min.js"></script>
		<!-- Moment JavaScript -->
		<script src="assets/js/moment.min.js"></script>
		<!-- FullCalendar JavaScript -->
		<script src="assets/js/fullcalendar.js"></script>
		<!-- FullCalendar Language JavaScript Selector -->
		<script src='assets/lang/en-gb.js'></script>
		<!-- DateTimePicker JavaScript -->
		<script type="text/javascript" src="assets/js/bootstrap-datetimepicker.js" charset="UTF-8"></script>
		<!-- Option 1: Bootstrap Bundle with Popper -->
        <script src="assets/js/bootstrap.bundle.min.js" ></script>  
		<!-- Datetime picker initialization -->
		<script type="text/javascript">	
			"use strict";
			$('.form_date').datetimepicker({
				language:  'en',
				weekStart: 1,
				todayBtn:  0,
				autoclose: 1,
				todayHighlight: 1,
				startView: 2,
				forceParse: 0
			});
		</script>	
		<!-- ColorPicker JavaScript -->
		<script src="assets/js/bootstrap-colorpicker.js"></script>
		<!-- Plugin Script Initialization for DataTables -->
		<script>
			"use strict";
			$(document).ready(function() {				
				$('.dataTables-example').dataTable();
			});
		</script>
		<!-- ColorPicker Initialization -->
		<script>
			"use strict";
			$(function() {
				"use strict";
				$('#cp1').colorpicker();
				$('#cp2').colorpicker();
			});
		
		</script>
		<!-- JS array created from database -->
		
		
		<script>		
		document.addEventListener('DOMContentLoaded', function() {
			 var calendarEl = document.getElementById('events');
        var events = new FullCalendar.Calendar(calendarEl, {
          initialView: 'dayGridMonth'
        });
			$('#events').fullCalendar({
				lang: 'en',
				defaultDate: '2022-11-16',
				editable: true,
				eventLimit: true,
				 selectable: true,
            plugins: ['interaction', 'dayGrid'],
				displayEventTime: true,					
				timeFormat: 'h(:mm)t', // displays 07am/pm
				header: {
					left: 'prev,next today',
					center: 'title',
					right: 'month,agendaWeek,agendaDay,listMonth'
				},				
				
				// Modal Box View							
				eventClick:  function(event, jsEvent, view) {					
					$('#modalTitle').html(event.title);
					var imgName=event.image;
					document.getElementById('imageDiv').innerHTML = '<img src='+imgName+' onerror=this.style.display="none" class=img-responsive alt= >';
					$('#modalBody').html(event.description);
					$('#modalBodyLoc').html(event.location);
					$('#startTime').html(moment(event.start).format('HH:mm'));
					$('#endTime').html(moment(event.end).format('HH:mm'));
					$('#eventUrl').attr('href',event.url);
					$('#fullCalModal').modal('show');
					
					 return false;
				},
				
				// Dragable Event Update
				eventDrop: function(event, delta) {
				   var start = $.fullCalendar.moment(event.start).format();
				   var end = $.fullCalendar.moment(event.end).format();
				   $.ajax({
				   url: 'events_update.php',
				   data: 'description='+ event.description +'&location='+ event.location +'&title='+ event.title +'&start='+ start +'&end='+ end +'&url='+ event.url +'&color='+ event.color +'&id='+ event.id ,
				   type: 'POST',
				   success: function(json) {
					swal('Good job!', 'Event Updated!', 'success');
						 setTimeout(function () {
							location.reload()
						}, 1000);
					}
				   });
				},
				
				// Popover View				
				eventRender: function(eventObj, element) {
					element.on('click', e => e.preventDefault());
					var imgName = eventObj.image;
					var start = moment(eventObj.start).format('HH:mm');
					var end = moment(eventObj.end).format('HH:mm');					
					  element.popover({	
						html: true,
						title: eventObj.title,
						//Use the folowing line if you want to display the title and date on pophover view title
						/*title: eventObj.title + ' ' + start + ' - ' + end,*/
						content: '<img src='+imgName+' class=img-responsive popover onerror=this.style.display="none" alt= >' + '<br/>' + eventObj.description,						
						trigger: 'hover',
						placement: 'bottom',
						container: 'body',					
					  });
				},	

				// Selectable date to create events
				selectHelper: true,
				selectable: true,	
				select: function( start, end, jsEvent, view ) {
					// set values in inputs
					$('#event1').find('input[name=start]').val(
						start.format('YYYY-MM-DD HH:mm')
					);
					$('#event1').find('input[name=end]').val(
						end.format('YYYY-MM-DD HH:mm')
					);					
					// show modal dialog
					$('#event1').modal('show');				   
				},

				events: [
					
					{
						id: '1400',
						title: 'Location',
						image: 'assets/uploads/',
						description: 'asdad',
						location: 'dssdsd',					
						start: '2022-11-13 19:10:00',
						end: '2022-11-20 23:30:00',
						url: 'asdsd',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1399',
						title: 'Location',
						image: 'assets/uploads/',
						description: 'hty',
						location: '5h',					
						start: '2022-11-01 14:10:00',
						end: '2022-11-24 14:10:00',
						url: 'dfdr',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1396',
						title: 'Faktura',
						image: 'assets/uploads/',
						description: '56j56j5',
						location: '6j56j5',					
						start: '2022-11-30 00:00:00',
						end: '2022-12-04 00:00:00',
						url: '6j56j56j',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1393',
						title: 'Location',
						image: 'assets/uploads/33e11643aa8dce683183cb584c3a3fd6.jpg',
						description: 'vbnbvn',
						location: 'vbnvbnvbn',					
						start: '2022-11-25 06:30:00',
						end: '2022-11-25 21:40:00',
						url: 'https://codecanyon.net/user/ezcode',
						color: '#ed0000',
						allDay: false
					},
					{
						id: '1394',
						title: 'No type Selected',
						image: 'assets/uploads/9750462cbed0e066918312a21ce9f91d.png',
						description: 'er',
						location: 'wr',					
						start: '2022-11-13 08:00:00',
						end: '2022-11-13 17:00:00',
						url: 'sagar.com',
						color: '#484e6c',
						allDay: false
					},
					{
						id: '1392',
						title: 'nuovo tipo',
						image: 'assets/uploads/24ee76c1ce54fd2b7b059e9aba6e9d85.jpg',
						description: 'xvbxvbxcvb',
						location: 'xcvbxbvxb',					
						start: '2022-11-26 18:40:00',
						end: '2022-11-26 22:50:00',
						url: 'https://codecanyon.net/user/ezcode',
						color: '#eb8814',
						allDay: false
					},
					{
						id: '1391',
						title: 'Conference',
						image: 'assets/uploads/bfc6a8af5f593c0cd93327419b7b9a1c.jpg',
						description: 'vbcvb',
						location: 'cvbcbcb',					
						start: '2022-11-25 00:00:00',
						end: '2022-11-26 00:00:00',
						url: 'https://codecanyon.net/user/ezcode',
						color: '#394bb6',
						allDay: false
					},
					{
						id: '1387',
						title: 'Faktura',
						image: 'assets/uploads/',
						description: 'test',
						location: '',					
						start: '2022-11-17 00:00:00',
						end: '2022-11-18 00:00:00',
						url: 'test',
						color: '#53ce8c',
						allDay: false
					},
					{
						id: '1405',
						title: 'Watch Party',
						image: 'assets/uploads/',
						description: 'Test',
						location: 'Japan',					
						start: '2022-11-17 08:00:00',
						end: '2022-11-19 22:50:00',
						url: 'https://c06f4633e8fbf280ff7b-531ca14677673103300e8c53210a758f.ssl.cf1.rackcdn.com/SEACRET_40933.png',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1404',
						title: 'aaa',
						image: 'assets/uploads/',
						description: 'Comanda XXXX -asdfl asldfj asldfkj asldg',
						location: 'oficines',					
						start: '2022-11-16 10:05:00',
						end: '2022-11-16 17:25:00',
						url: 'www.tactic.cc',
						color: '#e4e013',
						allDay: false
					},
					{
						id: '1382',
						title: 'Conference',
						image: 'assets/uploads/',
						description: 'regtr',
						location: 'ert',					
						start: '2023-01-01 00:00:00',
						end: '2023-01-02 00:00:00',
						url: 'http://www.tenwave.in/',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1401',
						title: 'Location',
						image: 'assets/uploads/63ca13de662b5ba613ca04acaf65075c.png',
						description: 'un nuevo logo',
						location: '',					
						start: '2022-11-14 00:00:00',
						end: '2022-11-15 00:00:00',
						url: 'nada',
						color: '#081d8a',
						allDay: false
					},
					{
						id: '1383',
						title: 'nuovo tipo',
						image: 'assets/uploads/1fc5e6d7783b0105e4162a39f894a3bd.jpg',
						description: 'daesaswd',
						location: 'safds',					
						start: '2022-12-31 00:00:00',
						end: '2023-01-01 00:00:00',
						url: 'https://www.tenwavehealthcare.com/',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1389',
						title: 'Test',
						image: 'assets/uploads/6f2b5234459707356e046cfbfa1dfc6c.jpg',
						description: 'test',
						location: 'portugal',					
						start: '2022-11-24 17:20:00',
						end: '2022-11-24 23:30:00',
						url: 'https://codecanyon.net/user/ezcode',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1374',
						title: 'Faktura',
						image: 'assets/uploads/',
						description: 'dfefsdf',
						location: '',					
						start: '2022-11-17 05:50:00',
						end: '2022-11-20 22:45:00',
						url: 'dxx',
						color: '#5367ce',
						allDay: false
					},
					{
						id: '1373',
						title: 'No type Selected',
						image: 'assets/uploads/bf33ea68114a458ea9d511baebf57d10.png',
						description: 'we are here for you',
						location: 'anywhere',					
						start: '2022-12-27 15:05:00',
						end: '2022-12-30 18:05:00',
						url: 'anysite.com',
						color: '#5367ce',
						allDay: false
					},
				],
						
			});				
		});			
	</script>
			
		<script>
			"use strict";
			// init Isotope
			var $grid = $('.grid').isotope({
			  itemSelector: '.element-item',
			  layoutMode: 'fitRows'
			});
			// filter functions
			var filterFns = {
			  // show if number is greater than 50
			  numberGreaterThan50: function() {
				var number = $(this).find('.number').text();
				return parseInt( number, 10 ) > 50;
			  },
			  // show if name ends with -ium
			  ium: function() {
				var name = $(this).find('.name').text();
				return name.match( /ium$/ );
			  }
			};
			// bind filter on select change
			$('.filters-select').on( 'change', function() {
			  // get filter value from option value
			  var filterValue = this.value;
			  // use filterFn if matches value
			  filterValue = filterFns[ filterValue ] || filterValue;
			  $grid.isotope({ filter: filterValue });
			});

			</script>
		
	</body>

</html>